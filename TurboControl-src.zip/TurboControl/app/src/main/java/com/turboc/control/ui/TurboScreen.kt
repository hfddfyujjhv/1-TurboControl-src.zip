package com.turboc.control.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.turboc.control.core.PowerMode
import com.turboc.control.core.TurboEngine
import kotlinx.coroutines.launch
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TurboScreen(modifier: Modifier = Modifier, viewModel: TurboViewModel = viewModel()) {
    val scope = rememberCoroutineScope()
    val isRoot by viewModel.isRoot.collectAsState()
    val uperfInstalled by viewModel.uperfInstalled.collectAsState()
    val refreshOn by viewModel.refreshOn.collectAsState()
    val schedOn by viewModel.schedOn.collectAsState()
    val currentMode by viewModel.currentMode.collectAsState()

    var toastMsg by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        viewModel.refresh()
    }

    // 监听刷新率和调度状态
    LaunchedEffect(refreshOn) { /* already tracked */ }
    LaunchedEffect(schedOn) { /* already tracked */ }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Turbo Control", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            // Root 状态横幅
            if (!isRoot) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFF5252))) {
                        Text("未获取 Root 权限，功能受限", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(12.dp))
                    }
                }
            }

            // 刷新率管理
            item {
                FeatureCard(
                    icon = Icons.Filled.Refresh,
                    title = "刷新率管理",
                    subtitle = if (refreshOn) "已锁定 144Hz" else "当前 ${viewModel.currentHz.value}Hz",
                    enabled = isRoot && uperfInstalled,
                    checked = refreshOn,
                    onToggle = {
                        scope.launch {
                            if (refreshOn) {
                                viewModel.setRefreshRate(false)
                            } else {
                                viewModel.setRefreshRate(true)
                            }
                        }
                    }
                )
            }

            // 调度接管（核心）
            item {
                FeatureCard(
                    icon = Icons.Filled.Speed,
                    title = "调度接管",
                    subtitle = if (schedOn) "MIUI 温控/降频已接管" else "系统默认调度",
                    enabled = isRoot && uperfInstalled,
                    checked = schedOn,
                    onToggle = {
                        scope.launch {
                            if (schedOn) {
                                viewModel.disableSchedTakeover()
                            } else {
                                viewModel.enableSchedTakeover()
                            }
                        }
                    }
                )
            }

            // Uperf 模式选择
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Uperf 模式", style = MaterialTheme.typography.titleSmall)
                        Text("切换性能档位（当前：${currentMode?.label ?: "未知"}）", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                            PowerMode.entries.forEach { mode ->
                                val selected = currentMode == mode
                                Button(
                                    onClick = { scope.launch { viewModel.setMode(mode) } },
                                    enabled = isRoot && uperfInstalled,
                                    modifier = Modifier.weight(1f).height(36.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondaryContainer,
                                        contentColor = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                ) {
                                    Text(mode.label, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }

            // FPS 悬浮窗开关
            item {
                FeatureCard(
                    icon = Icons.Filled.Tune,
                    title = "FPS 悬浮窗",
                    subtitle = if (viewModel.fpsOverlayOn.value) "游戏内显示 FPS" else "关闭",
                    enabled = isRoot,
                    checked = viewModel.fpsOverlayOn.value,
                    onToggle = {
                        scope.launch { viewModel.toggleFpsOverlay() }
                    }
                )
            }

            // 状态信息
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("设备信息", style = MaterialTheme.typography.titleSmall)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("SoC: ${viewModel.socName.value}", style = MaterialTheme.typography.bodySmall)
                        Text("当前模式: ${currentMode?.label ?: "--"}", style = MaterialTheme.typography.bodySmall)
                        Text("Uperf: ${if (uperfInstalled) "已安装" else "未安装"}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun FeatureCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    enabled: Boolean,
    checked: Boolean,
    onToggle: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled, onClick = onToggle),
        colors = CardDefaults.cardColors(
            containerColor = if (checked) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = title, tint = if (checked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                Column {
                    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Switch(checked = checked, enabled = enabled, onCheckedChange = { onToggle() })
        }
    }
}
